// event listener for the colors div
$('.colors').click(function()
	{
		// Using "this", we can let jQuery figure out which one was clicked
		var chosen_color = $(this).css('background-color');
		//console.log(chosen_color);
		// Set the color on the canvas
		$('#canvas').css('background-color', chosen_color);
		// Set the color on the texture
		$('.textures').css('background-color', chosen_color);
	}); 
	
// event listener for the textures div
$('.textures').click(function()
	{
		// Using "this", we can let jQuery figure out which one was clicked
		var chosen_texture = $(this).css('background'); 
		//console.log(chosen_texture);
		// Set the texture on the canvas
		$('#canvas').css('background', chosen_texture);
	}); 
	
// event listener for radio button message
$('.messages').click(function() {

	 // Which radio button was clicked?
	 // (Note here how we're storing a whole element in a variable... cool, huh?)
	 var radio_button = $(this);
		//console.log(radio_button);

	 // What is the label next to (i.e., after) that radio 
	 var label = radio_button.next();

	 // Now that we know the label, grab the text inside of it (That's our message!)
	 var message = label.html();
	 
	 // Set output on the canvas
	 $('#message-output').html(message);

});
	// User Name ... what did the user type
    $('#recipient').keyup(function() {
		
		// store what the user typed
		var recipient = $(this).val();
		
		// Inject what the user typed in into the #recipient-output div in the card.
		$('#recipient-output').html("Dear" + " " + recipient);
	
		// How many characters long is the name?	
		var length = recipient.length;
		
		// If it were 14 characters, that's the max, so inject an error message
		//if (length == 14) 
		if (length == $(this).prop('maxLength'))

		$('#recipient-error').html("Max characters: 14");
		else {
		// all is well
		$('#recipient-error').html(" ");
		}
		
	});
	
	// Stickers long hand approach
	
//	$('.stickers').click(function() {

	 // Find the src (i.e., path) of the image (i.e., sticker) that was just clicked
//	 var which_sticker = $(this).attr('src');

	 // Generate a new image with that path
	 // Remember that the plus sign is used to "concatenate" (i.e., join) together pieces. 
	 // So here we're joining together some HTML code plus a variable plus some more HTML code.
//	 var new_sticker = '<img src="'+ which_sticker +'">';

	 // If, for example, the star was clicked, the above line would result in this:
	 // <img src="images/sticker-star.png">

	 // Finally, inject the new image into the canvas
	 // Use prepend so it gets added *before* any other content already in 
	 // the canvas (like our message and recipient divs)
//	 $('#canvas').prepend(new_sticker);

//	});

	// Stickers clone
	$('.stickers').click(function() {
		
	 	// Clone the sticker that was clicked!
		var new_sticker = $(this).clone();
		
		// Give all the stickers on the card the same class so we can absolutely position them
		new_sticker.addClass('stickers_on_card');
			
		// Inject the new image into the canvas
		$('#canvas').prepend(new_sticker);
		
		// Make the new sticker draggable
		new_sticker.draggable({ opacity: 0.35 });
		
		// Make the new sticker draggable and set the 
		// "containment" option to be the #canvas div.
		// I.e., don't let the stickers be dragged out of the canvas
		new_sticker.draggable({containment:'#canvas'});
		
		
		// Tip: Make sure you include those curly brackets {} 
		// around the containment option...otherwise it won't work!
		});
	
// Puts a D before the example text
// $('#example').prepend("D");

// Puts a D after the example text
// $('#example').append("D");

// Stores the example and then adds a string to it but doesn't output it.
//var existing_text = $('#example').html;
//$('#example').html(existing_text + "D");